export type TimeFrame = '1m' | '5m' | '15m' | '1h' | '4h' | '1d';

export type SignalType = 'LONG' | 'SHORT' | 'REJECT_LONG' | 'REJECT_SHORT';

export type PatternType = 'bullish' | 'bearish' | 'neutral';

export interface Candle {
  time: number; // Timestamp or index
  timeLabel: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  ema20?: number;
  ema50?: number;
  ema200?: number;
  rsi?: number;
  macd?: { macd: number; signal: number; hist: number };
  upperBB?: number;
  lowerBB?: number;
  middleBB?: number;
  supertrend?: number;
  isSupertrendBullish?: boolean;
}

export interface PatternMatch {
  id: string;
  patternName: string; // e.g. "Bullish Engulfing", "Shooting Star", "Double Bottom (W)", "Head & Shoulders"
  type: PatternType;
  confidence: number; // e.g., 98.7
  candleIndex: number;
  description: string;
  timeframe: TimeFrame;
  action: SignalType;
  rejectionWarning?: string; // Warning if movement is about to get rejected
}

export interface CryptoCoin {
  symbol: string;
  name: string;
  price: number;
  change24h: number;
  high24h: number;
  low24h: number;
  volume24h: number;
  category: 'Delta Exchange Top' | 'Layer 1' | 'DeFi' | 'Meme' | 'AI Tokens';
  rsi: number;
  trendSignal: 'STRONG_BULL' | 'BULLISH' | 'NEUTRAL' | 'BEARISH' | 'STRONG_BEAR';
  momentumScore: number; // 0 - 100
  activePattern: string;
  isReversalBottom: boolean; // Bull run bottom
  isReversalTop: boolean; // Market crash top
  smallSLPipsPct: number; // e.g. 0.4%
  accuracyScore: number; // e.g. 98.9%
  lastUpdated: string;
}

export interface TradeSignal {
  id: string;
  symbol: string;
  coinName: string;
  direction: 'LONG' | 'SHORT';
  timeframe: TimeFrame;
  currentPrice: number;
  entryRangeMin: number;
  entryRangeMax: number;
  stopLoss: number;
  tp1: number;
  tp2: number;
  tp3: number;
  riskRewardRatio: string;
  smallSLPercent: number; // e.g. 0.45%
  accuracyScore: number; // 98.5% to 99.2%
  patternTrigger: string;
  confluenceReason: string[];
  rejectionCheckPassed: boolean;
  status: 'ACTIVE' | 'HIT_TP1' | 'HIT_TP2' | 'HIT_TP3' | 'HIT_SL' | 'REJECTED';
  timestamp: string;
  isBullRunBottom?: boolean;
  isTopCrashReversal?: boolean;
}

export interface MarketAlert {
  id: string;
  symbol: string;
  title: string;
  message: string;
  price: number;
  type: 'ENTRY' | 'EXIT_TP' | 'EXIT_SL' | 'PATTERN' | 'BOTTOM_HUNTER' | 'TOP_HUNTER' | 'REJECTION_WARNING';
  timestamp: string;
  isRead: boolean;
  accuracy: number;
  timeframe: TimeFrame;
}

export interface GeminiAnalysisResponse {
  coin: string;
  timeframe: string;
  overallDirection: 'BULLISH' | 'BEARISH' | 'NEUTRAL_REJECT';
  confidenceScore: number;
  hinglishSummary: string;
  candlestickPatternFound: string;
  keySupport: number;
  keyResistance: number;
  rejectionWarning: string;
  recommendedEntry: number;
  recommendedStopLoss: number;
  recommendedTakeProfit: number;
  riskReward: string;
}
