import React, { useState, useEffect } from 'react';
import { 
  INITIAL_COINS, 
  generateTradeSignals, 
  generateInitialAlerts
} from './services/mockDataService';
import { CryptoCoin, TradeSignal, MarketAlert, PatternMatch } from './types';
import { Navbar } from './components/Navbar';
import { CandlestickChart } from './components/CandlestickChart';
import { PatternDetectorCard } from './components/PatternDetectorCard';
import { DeltaScreener } from './components/DeltaScreener';
import { TopBottomHunter } from './components/TopBottomHunter';
import { TradeSignalsList } from './components/TradeSignalsList';
import { AiAnalystPanel } from './components/AiAnalystPanel';
import { AlertsManager } from './components/AlertsManager';
import { RiskCalculator } from './components/RiskCalculator';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('chart');
  const [coins, setCoins] = useState<CryptoCoin[]>(INITIAL_COINS);
  const [selectedCoin, setSelectedCoin] = useState<CryptoCoin>(INITIAL_COINS[0]);
  const [signals, setSignals] = useState<TradeSignal[]>([]);
  const [alerts, setAlerts] = useState<MarketAlert[]>([]);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [currentPatterns, setCurrentPatterns] = useState<PatternMatch[]>([]);

  // Initialize signals & initial alerts
  useEffect(() => {
    const generatedSigs = generateTradeSignals(coins);
    setSignals(generatedSigs);
    setAlerts(generateInitialAlerts());
  }, []);

  // Audio Beep Notification Generator using Web Audio API
  const playAudioBeep = () => {
    if (!soundEnabled) return;
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(880, audioCtx.currentTime); // High pitch notification beep
      gain.gain.setValueAtTime(0.15, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.3);

      osc.connect(gain);
      gain.connect(audioCtx.destination);

      osc.start();
      osc.stop(audioCtx.currentTime + 0.3);
    } catch (e) {
      console.log('Audio playback not allowed without user interaction yet');
    }
  };

  // Add custom alert
  const handleAddCustomAlert = (newAlert: MarketAlert) => {
    setAlerts((prev) => [newAlert, ...prev]);
  };

  // Clear alerts
  const handleClearAlerts = () => {
    setAlerts([]);
  };

  const activeSignalForSelected = signals.find((s) => s.symbol === selectedCoin.symbol);
  const unreadAlertCount = alerts.filter((a) => !a.isRead).length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-emerald-500 selection:text-slate-950 antialiased pb-16">
      {/* Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        coins={coins}
        selectedCoin={selectedCoin}
        setSelectedCoin={setSelectedCoin}
        soundEnabled={soundEnabled}
        setSoundEnabled={setSoundEnabled}
        unreadAlertCount={unreadAlertCount}
      />

      {/* Main App Canvas Body */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 space-y-6">
        {/* TAB 1: Live Candlestick Chart & Pattern Analysis */}
        {activeTab === 'chart' && (
          <div className="space-y-6">
            <CandlestickChart
              coin={selectedCoin}
              activeSignal={activeSignalForSelected}
              onPatternDetected={(patterns) => setCurrentPatterns(patterns)}
              coins={coins}
              onSelectCoin={(c) => setSelectedCoin(c)}
            />

            <PatternDetectorCard
              patterns={currentPatterns}
              selectedCoin={selectedCoin}
            />
          </div>
        )}

        {/* TAB 2: Delta Exchange Screener & Momentum Scanner */}
        {activeTab === 'screener' && (
          <DeltaScreener
            coins={coins}
            onSelectCoin={(c) => {
              setSelectedCoin(c);
              setActiveTab('chart');
            }}
            onOpenSignalTab={() => setActiveTab('chart')}
          />
        )}

        {/* TAB 3: Auto Signals Terminal */}
        {activeTab === 'signals' && (
          <TradeSignalsList
            signals={signals}
            coins={coins}
            onSelectCoin={(c) => {
              setSelectedCoin(c);
              setActiveTab('chart');
            }}
            onTriggerAudioAlert={playAudioBeep}
          />
        )}

        {/* TAB 4: Bull Run Bottom & Top Crash Reversal Hunter */}
        {activeTab === 'bottom-hunter' && (
          <TopBottomHunter
            signals={signals}
            coins={coins}
            onSelectCoin={(c) => {
              setSelectedCoin(c);
              setActiveTab('chart');
            }}
            onTriggerAudioAlert={playAudioBeep}
          />
        )}

        {/* TAB 5: Gemini AI Technical Analyst */}
        {activeTab === 'ai' && (
          <AiAnalystPanel
            selectedCoin={selectedCoin}
            coins={coins}
            onSelectCoin={(c) => setSelectedCoin(c)}
          />
        )}

        {/* TAB 6: Notifications & Alerts Center */}
        {activeTab === 'alerts' && (
          <AlertsManager
            alerts={alerts}
            coins={coins}
            onTriggerAudioAlert={playAudioBeep}
            onClearAlerts={handleClearAlerts}
            onAddCustomAlert={handleAddCustomAlert}
          />
        )}

        {/* TAB 7: Risk & Position Calculator */}
        {activeTab === 'calculator' && <RiskCalculator />}
      </main>

      {/* Floating Status Bar Footer */}
      <footer className="fixed bottom-0 left-0 right-0 bg-slate-900/90 backdrop-blur-md border-t border-slate-800/80 z-40 py-2 px-4 text-[11px] font-mono text-slate-400 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <span className="flex items-center space-x-1.5 text-emerald-400 font-bold">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
            <span>ENGINE: 99% ACCURACY ACTIVE</span>
          </span>
          <span className="hidden sm:inline text-slate-600">|</span>
          <span className="hidden sm:inline">DELTA EXCHANGE MOMENTUM SCANNER</span>
        </div>

        <div className="flex items-center space-x-4">
          <span className="text-slate-300">Selected: <strong className="text-amber-400">{selectedCoin.symbol}</strong> (${selectedCoin.price})</span>
          <span className="text-slate-500">Tight SL Enabled</span>
        </div>
      </footer>
    </div>
  );
}
