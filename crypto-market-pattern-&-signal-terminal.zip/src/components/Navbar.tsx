import React from 'react';
import { 
  BarChart3, 
  TrendingUp, 
  Zap, 
  Target, 
  Bell, 
  Bot, 
  Calculator, 
  Volume2, 
  VolumeX, 
  ShieldAlert, 
  Activity,
  Flame
} from 'lucide-react';
import { CryptoCoin } from '../types';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  coins: CryptoCoin[];
  selectedCoin: CryptoCoin;
  setSelectedCoin: (coin: CryptoCoin) => void;
  soundEnabled: boolean;
  setSoundEnabled: (val: boolean) => void;
  unreadAlertCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  coins,
  selectedCoin,
  setSelectedCoin,
  soundEnabled,
  setSoundEnabled,
  unreadAlertCount,
}) => {
  return (
    <header className="bg-slate-900 border-b border-slate-800 sticky top-0 z-50">
      {/* Top Live Ticker Marquee */}
      <div className="bg-slate-950 px-4 py-1.5 border-b border-slate-800/60 overflow-x-auto no-scrollbar flex items-center space-x-6 text-xs font-mono">
        <div className="flex items-center space-x-1.5 text-emerald-400 font-semibold shrink-0">
          <Activity className="w-3.5 h-3.5 animate-pulse" />
          <span>DELTA LIVE TICKER:</span>
        </div>
        <div className="flex items-center space-x-6 shrink-0">
          {coins.map((coin) => (
            <button
              key={coin.symbol}
              onClick={() => setSelectedCoin(coin)}
              className={`flex items-center space-x-2 transition-all hover:opacity-100 ${
                selectedCoin.symbol === coin.symbol ? 'opacity-100 font-bold text-amber-400' : 'opacity-75 text-slate-300'
              }`}
            >
              <span>{coin.symbol}</span>
              <span className="text-slate-100">${coin.price < 1 ? coin.price.toFixed(4) : coin.price.toLocaleString()}</span>
              <span className={coin.change24h >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                {coin.change24h >= 0 ? '+' : ''}{coin.change24h}%
              </span>
              {coin.isReversalBottom && (
                <span className="bg-emerald-500/20 text-emerald-300 px-1 rounded text-[10px] font-sans font-bold">
                  BULL BOTTOM
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Title */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 via-teal-500 to-cyan-500 p-0.5 shadow-lg shadow-emerald-500/20">
              <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                <TrendingUp className="w-5 h-5 text-emerald-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-lg font-bold text-white tracking-wide font-sans">
                  CRYPTO<span className="text-emerald-400">PULSE</span> Pro
                </h1>
                <span className="bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 text-[10px] font-mono px-2 py-0.5 rounded-full uppercase tracking-wider font-semibold">
                  99% Accuracy Engine
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block">
                Candlestick Pattern Signal Terminal & Delta Momentum Hunter
              </p>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="hidden md:flex items-center space-x-1">
            <button
              onClick={() => setActiveTab('chart')}
              className={`flex items-center space-x-2 px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                activeTab === 'chart'
                  ? 'bg-slate-800 text-emerald-400 border border-emerald-500/30 shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <BarChart3 className="w-4 h-4" />
              <span>Live Chart</span>
            </button>

            <button
              onClick={() => setActiveTab('screener')}
              className={`flex items-center space-x-2 px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                activeTab === 'screener'
                  ? 'bg-slate-800 text-emerald-400 border border-emerald-500/30 shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Zap className="w-4 h-4 text-amber-400" />
              <span>Delta Screener</span>
            </button>

            <button
              onClick={() => setActiveTab('signals')}
              className={`flex items-center space-x-2 px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                activeTab === 'signals'
                  ? 'bg-slate-800 text-emerald-400 border border-emerald-500/30 shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Target className="w-4 h-4 text-cyan-400" />
              <span>Auto Signals</span>
            </button>

            <button
              onClick={() => setActiveTab('bottom-hunter')}
              className={`flex items-center space-x-2 px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                activeTab === 'bottom-hunter'
                  ? 'bg-slate-800 text-emerald-400 border border-emerald-500/30 shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Flame className="w-4 h-4 text-emerald-400 animate-bounce" />
              <span>Reversal Hunter</span>
            </button>

            <button
              onClick={() => setActiveTab('ai')}
              className={`flex items-center space-x-2 px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                activeTab === 'ai'
                  ? 'bg-slate-800 text-emerald-400 border border-emerald-500/30 shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Bot className="w-4 h-4 text-indigo-400" />
              <span>Gemini AI Analyst</span>
            </button>

            <button
              onClick={() => setActiveTab('calculator')}
              className={`flex items-center space-x-2 px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                activeTab === 'calculator'
                  ? 'bg-slate-800 text-emerald-400 border border-emerald-500/30 shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              <Calculator className="w-4 h-4 text-teal-400" />
              <span>Risk Calculator</span>
            </button>
          </nav>

          {/* Right Action Controls */}
          <div className="flex items-center space-x-3">
            {/* Sound Notification Toggle */}
            <button
              onClick={() => setSoundEnabled(!soundEnabled)}
              title={soundEnabled ? 'Audio Alerts Enabled' : 'Audio Alerts Muted'}
              className="p-2 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition"
            >
              {soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
            </button>

            {/* Alerts Center Tab */}
            <button
              onClick={() => setActiveTab('alerts')}
              className="relative p-2 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition"
            >
              <Bell className="w-4 h-4" />
              {unreadAlertCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-rose-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center animate-pulse">
                  {unreadAlertCount}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Mobile Tab Bar */}
        <div className="md:hidden flex items-center justify-between py-2 border-t border-slate-800/60 overflow-x-auto no-scrollbar space-x-2 text-xs">
          <button
            onClick={() => setActiveTab('chart')}
            className={`px-3 py-1.5 rounded-md whitespace-nowrap ${
              activeTab === 'chart' ? 'bg-emerald-500/20 text-emerald-400 font-bold' : 'text-slate-400'
            }`}
          >
            Chart
          </button>
          <button
            onClick={() => setActiveTab('screener')}
            className={`px-3 py-1.5 rounded-md whitespace-nowrap ${
              activeTab === 'screener' ? 'bg-emerald-500/20 text-emerald-400 font-bold' : 'text-slate-400'
            }`}
          >
            Screener
          </button>
          <button
            onClick={() => setActiveTab('signals')}
            className={`px-3 py-1.5 rounded-md whitespace-nowrap ${
              activeTab === 'signals' ? 'bg-emerald-500/20 text-emerald-400 font-bold' : 'text-slate-400'
            }`}
          >
            Signals
          </button>
          <button
            onClick={() => setActiveTab('bottom-hunter')}
            className={`px-3 py-1.5 rounded-md whitespace-nowrap ${
              activeTab === 'bottom-hunter' ? 'bg-emerald-500/20 text-emerald-400 font-bold' : 'text-slate-400'
            }`}
          >
            Reversal Hunter
          </button>
          <button
            onClick={() => setActiveTab('ai')}
            className={`px-3 py-1.5 rounded-md whitespace-nowrap ${
              activeTab === 'ai' ? 'bg-emerald-500/20 text-emerald-400 font-bold' : 'text-slate-400'
            }`}
          >
            AI Analyst
          </button>
        </div>
      </div>
    </header>
  );
};
