import React, { useState } from 'react';
import { Calculator, ShieldCheck, DollarSign, Percent, AlertCircle } from 'lucide-react';

export const RiskCalculator: React.FC = () => {
  const [accountBalance, setAccountBalance] = useState<number>(1000);
  const [riskPercentage, setRiskPercentage] = useState<number>(1.5); // Risk 1.5% of capital
  const [entryPrice, setEntryPrice] = useState<number>(94280);
  const [stopLossPrice, setStopLossPrice] = useState<number>(93900);
  const [leverage, setLeverage] = useState<number>(20);

  // Calculations
  const riskAmountUSD = (accountBalance * riskPercentage) / 100;
  const priceDiff = Math.abs(entryPrice - stopLossPrice);
  const slPercentage = entryPrice > 0 ? (priceDiff / entryPrice) * 100 : 0;

  // Position Size in USD
  const positionSizeUSD = slPercentage > 0 ? riskAmountUSD / (slPercentage / 100) : 0;
  const marginRequiredUSD = leverage > 0 ? positionSizeUSD / leverage : positionSizeUSD;
  const cryptoUnits = entryPrice > 0 ? positionSizeUSD / entryPrice : 0;

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl relative overflow-hidden">
        <div className="flex items-center space-x-3">
          <Calculator className="w-6 h-6 text-teal-400" />
          <div>
            <h2 className="text-xl font-bold text-white font-sans">
              Small SL Risk & Position Size Calculator
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Calculate exact lot size, contract size, and margin required on Delta Exchange for small Stop Loss setups.
            </p>
          </div>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Input Form */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl space-y-4">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider pb-2 border-b border-slate-800 font-sans">
            Trade Input Parameters
          </h3>

          <div>
            <label className="text-xs text-slate-400 block mb-1">Account Balance ($)</label>
            <div className="relative">
              <DollarSign className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
              <input
                type="number"
                value={accountBalance}
                onChange={(e) => setAccountBalance(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 text-white font-bold pl-9 pr-3 py-2.5 rounded-xl text-sm focus:outline-none focus:border-emerald-500 font-mono"
              />
            </div>
          </div>

          <div>
            <label className="text-xs text-slate-400 block mb-1">Max Capital Risk (%)</label>
            <div className="relative">
              <Percent className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
              <input
                type="number"
                step="0.1"
                value={riskPercentage}
                onChange={(e) => setRiskPercentage(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 text-white font-bold pl-9 pr-3 py-2.5 rounded-xl text-sm focus:outline-none focus:border-emerald-500 font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-slate-400 block mb-1">Entry Price ($)</label>
              <input
                type="number"
                value={entryPrice}
                onChange={(e) => setEntryPrice(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 text-white font-bold p-2.5 rounded-xl text-sm focus:outline-none focus:border-emerald-500 font-mono"
              />
            </div>

            <div>
              <label className="text-xs text-slate-400 block mb-1">Stop Loss Price ($)</label>
              <input
                type="number"
                value={stopLossPrice}
                onChange={(e) => setStopLossPrice(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 text-rose-400 font-bold p-2.5 rounded-xl text-sm focus:outline-none focus:border-rose-500 font-mono"
              />
            </div>
          </div>

          <div>
            <label className="text-xs text-slate-400 block mb-1">Delta Exchange Leverage ({leverage}x)</label>
            <input
              type="range"
              min="1"
              max="100"
              value={leverage}
              onChange={(e) => setLeverage(Number(e.target.value))}
              className="w-full accent-emerald-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-1">
              <span>1x (Spot)</span>
              <span>25x</span>
              <span>50x</span>
              <span>100x</span>
            </div>
          </div>
        </div>

        {/* Calculation Output Cards */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl flex flex-col justify-between space-y-4">
          <h3 className="text-sm font-bold text-white uppercase tracking-wider pb-2 border-b border-slate-800 font-sans">
            Position Sizing Output
          </h3>

          <div className="space-y-3 font-mono text-xs">
            <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 flex items-center justify-between">
              <span className="text-slate-400">Max USD Risk Amount:</span>
              <span className="text-rose-400 font-extrabold text-sm">${riskAmountUSD.toFixed(2)}</span>
            </div>

            <div className="bg-slate-950 p-3.5 rounded-xl border border-amber-500/30 flex items-center justify-between">
              <span className="text-slate-400">Small Stop Loss (%):</span>
              <span className="text-amber-400 font-extrabold text-sm">{slPercentage.toFixed(2)}%</span>
            </div>

            <div className="bg-slate-950 p-3.5 rounded-xl border border-emerald-500/30 flex items-center justify-between">
              <span className="text-slate-400">Total Position Size (USD):</span>
              <span className="text-emerald-400 font-extrabold text-sm">${positionSizeUSD.toFixed(2)}</span>
            </div>

            <div className="bg-slate-950 p-3.5 rounded-xl border border-cyan-500/30 flex items-center justify-between">
              <span className="text-slate-400">Margin Required ({leverage}x):</span>
              <span className="text-cyan-400 font-extrabold text-sm">${marginRequiredUSD.toFixed(2)}</span>
            </div>

            <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 flex items-center justify-between">
              <span className="text-slate-400">Crypto Units / Lot Size:</span>
              <span className="text-white font-extrabold text-sm">{cryptoUnits.toFixed(4)} Units</span>
            </div>
          </div>

          <div className="bg-emerald-950/20 border border-emerald-500/30 p-3 rounded-xl flex items-center space-x-2 text-[11px] text-emerald-400">
            <ShieldCheck className="w-4 h-4 shrink-0" />
            <span>Small SL enforces 1:{Math.round((1 / (slPercentage / 100)) * 0.15)} minimum Risk-Reward safety.</span>
          </div>
        </div>
      </div>
    </div>
  );
};
