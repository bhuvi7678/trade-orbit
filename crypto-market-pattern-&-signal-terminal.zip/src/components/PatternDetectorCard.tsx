import React from 'react';
import { PatternMatch, CryptoCoin } from '../types';
import { ShieldAlert, CheckCircle2, TrendingUp, TrendingDown, Target, Zap, AlertTriangle } from 'lucide-react';

interface PatternDetectorCardProps {
  patterns: PatternMatch[];
  selectedCoin: CryptoCoin;
}

export const PatternDetectorCard: React.FC<PatternDetectorCardProps> = ({
  patterns,
  selectedCoin,
}) => {
  if (!patterns || patterns.length === 0) return null;

  const mainPattern = patterns[0];
  const isBullish = mainPattern.type === 'bullish';

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl relative overflow-hidden">
      {/* Top Banner */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div className="flex items-center space-x-2">
          <Zap className="w-5 h-5 text-amber-400" />
          <h3 className="text-sm font-bold text-white uppercase tracking-wider font-sans">
            Live Pattern Recognition & Rejection Shield
          </h3>
        </div>
        <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-[11px] font-mono px-2.5 py-1 rounded-full font-bold">
          {mainPattern.confidence}% Accuracy Confirmed
        </span>
      </div>

      {/* Pattern Main Info */}
      <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Left Side: Pattern Badge & Direction */}
        <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex flex-col justify-between">
          <div>
            <span className="text-[11px] font-mono uppercase text-slate-400 tracking-wider">
              Detected Setup ({mainPattern.timeframe})
            </span>
            <div className="flex items-center space-x-2 mt-1">
              <h4 className="text-lg font-black text-white font-sans">{mainPattern.patternName}</h4>
              <span
                className={`text-xs px-2.5 py-0.5 rounded-md font-extrabold flex items-center space-x-1 ${
                  isBullish ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' : 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
                }`}
              >
                {isBullish ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
                <span>{mainPattern.action}</span>
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-2 leading-relaxed">{mainPattern.description}</p>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs font-mono">
            <span className="text-slate-400">Recommended SL:</span>
            <span className="text-amber-400 font-bold">Tight ~{selectedCoin.smallSLPipsPct}%</span>
          </div>
        </div>

        {/* Right Side: Rejection Warning Shield */}
        <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex flex-col justify-between">
          <div>
            <div className="flex items-center space-x-2 text-rose-400 font-bold text-xs uppercase tracking-wider font-sans">
              <ShieldAlert className="w-4 h-4" />
              <span>Fake Move / Rejection Filter</span>
            </div>
            
            <p className="text-xs text-slate-300 mt-2 leading-relaxed">
              {mainPattern.rejectionWarning ||
                `System evaluated resistance levels for ${selectedCoin.symbol}. No overhead rejection found. Safe to execute trade setup.`}
            </p>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center space-x-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="text-[11px] text-emerald-400 font-mono font-medium">
              Confluence Cleared: RSI + EMA20 + Volume Spike
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
