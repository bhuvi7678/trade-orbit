import React, { useState, useEffect, useRef } from 'react';
import { Candle, CryptoCoin, PatternMatch, TimeFrame, TradeSignal } from '../types';
import { generateCandlesticks, detectPatterns } from '../services/mockDataService';
import { 
  BarChart2, 
  Eye, 
  Layers, 
  TrendingUp, 
  TrendingDown, 
  Maximize2, 
  RefreshCw, 
  CheckCircle2, 
  AlertTriangle,
  Zap,
  Target
} from 'lucide-react';

interface CandlestickChartProps {
  coin: CryptoCoin;
  activeSignal?: TradeSignal;
  onPatternDetected?: (patterns: PatternMatch[]) => void;
  coins: CryptoCoin[];
  onSelectCoin: (coin: CryptoCoin) => void;
}

export const CandlestickChart: React.FC<CandlestickChartProps> = ({
  coin,
  activeSignal,
  onPatternDetected,
  coins,
  onSelectCoin,
}) => {
  const [timeframe, setTimeframe] = useState<TimeFrame>('15m');
  const [candles, setCandles] = useState<Candle[]>([]);
  const [patterns, setPatterns] = useState<PatternMatch[]>([]);
  const [hoveredCandle, setHoveredCandle] = useState<Candle | null>(null);

  // Indicator Toggles
  const [showEMA20, setShowEMA20] = useState(true);
  const [showEMA50, setShowEMA50] = useState(true);
  const [showBB, setShowBB] = useState(false);
  const [showSupertrend, setShowSupertrend] = useState(true);
  const [showTradeLevels, setShowTradeLevels] = useState(true);

  // SVG Chart container dimensions
  const svgRef = useRef<SVGSVGElement | null>(null);
  const [svgWidth, setSvgWidth] = useState(900);
  const svgHeight = 440;

  // Handle ResizeObserver
  useEffect(() => {
    const handleResize = () => {
      if (svgRef.current && svgRef.current.parentElement) {
        setSvgWidth(svgRef.current.parentElement.clientWidth || 900);
      }
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Fetch / Generate live candles
  useEffect(() => {
    const data = generateCandlesticks(coin.symbol, coin.price, timeframe, 50);
    setCandles(data);
    const detected = detectPatterns(data, timeframe);
    setPatterns(detected);
    if (onPatternDetected) onPatternDetected(detected);
  }, [coin.symbol, coin.price, timeframe]);

  // Live simulation tick every 3 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setCandles((prev) => {
        if (!prev || prev.length === 0) return prev;
        const last = { ...prev[prev.length - 1] };
        const priceChange = (Math.random() - 0.48) * (coin.price * 0.001);
        last.close = Math.max(0.0001, last.close + priceChange);
        last.high = Math.max(last.high, last.close);
        last.low = Math.min(last.low, last.close);

        const updated = [...prev.slice(0, prev.length - 1), last];
        const newPatterns = detectPatterns(updated, timeframe);
        setPatterns(newPatterns);
        return updated;
      });
    }, 3000);
    return () => clearInterval(interval);
  }, [timeframe, coin.price]);

  if (candles.length === 0) return null;

  // Min / Max calculation for scaling
  const prices = candles.flatMap((c) => [c.high, c.low]);
  if (activeSignal && showTradeLevels) {
    prices.push(activeSignal.stopLoss, activeSignal.tp1, activeSignal.tp2, activeSignal.tp3);
  }
  const minPrice = Math.min(...prices) * 0.998;
  const maxPrice = Math.max(...prices) * 1.002;
  const priceRange = maxPrice - minPrice || 1;

  // Volume min/max
  const maxVol = Math.max(...candles.map((c) => c.volume)) || 1;

  // Layout math inside SVG
  const chartPaddingTop = 30;
  const chartHeight = 310;
  const volumeHeight = 80;
  const volumeTop = chartHeight + 20;

  const candleCount = candles.length;
  const candleGap = svgWidth / candleCount;
  const candleWidth = Math.max(3, candleGap * 0.65);

  const getY = (price: number) => {
    return chartPaddingTop + chartHeight - ((price - minPrice) / priceRange) * chartHeight;
  };

  const getVolY = (vol: number) => {
    return svgHeight - (vol / maxVol) * volumeHeight;
  };

  // Support & Resistance Pivot calculation
  const currentPrice = candles[candles.length - 1].close;
  const supportPivot = minPrice * 1.001;
  const resistancePivot = maxPrice * 0.999;

  return (
    <div className="bg-[#0A0A0A] border border-[#222222] rounded-2xl p-5 shadow-2xl relative overflow-hidden">
      {/* Chart Header Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-3 border-b border-[#222222]">
        {/* Coin Info Dropdown */}
        <div className="flex items-center space-x-3">
          <select
            value={coin.symbol}
            onChange={(e) => {
              const found = coins.find((c) => c.symbol === e.target.value);
              if (found) onSelectCoin(found);
            }}
            className="bg-[#111111] border border-[#222222] text-white font-bold font-sans text-base px-3 py-1.5 rounded-xl focus:outline-none focus:border-[#00FFA3] cursor-pointer"
          >
            {coins.map((c) => (
              <option key={c.symbol} value={c.symbol}>
                {c.symbol} ({c.name})
              </option>
            ))}
          </select>

          <div className="flex items-center space-x-2 font-mono">
            <span className="text-xl font-extrabold text-white">
              ${coin.price < 1 ? coin.price.toFixed(4) : coin.price.toLocaleString()}
            </span>
            <span
              className={`text-xs px-2 py-0.5 rounded-md font-bold flex items-center space-x-1 ${
                coin.change24h >= 0 ? 'bg-[#00FFA3]/20 text-[#00FFA3] border border-[#00FFA3]/30' : 'bg-[#FF3B30]/20 text-[#FF3B30] border border-[#FF3B30]/30'
              }`}
            >
              {coin.change24h >= 0 ? <TrendingUp className="w-3.5 h-3.5 text-[#00FFA3]" /> : <TrendingDown className="w-3.5 h-3.5 text-[#FF3B30]" />}
              <span>{coin.change24h >= 0 ? '+' : ''}{coin.change24h}%</span>
            </span>
          </div>
        </div>

        {/* Timeframe & Technical Overlay Toolbar */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Timeframe Buttons */}
          <div className="bg-[#111111] p-1 rounded-xl border border-[#222222] flex items-center space-x-1 text-xs font-mono font-medium">
            {(['1m', '5m', '15m', '1h', '4h', '1d'] as TimeFrame[]).map((tf) => (
              <button
                key={tf}
                onClick={() => setTimeframe(tf)}
                className={`px-2.5 py-1 rounded-lg transition-all ${
                  timeframe === tf ? 'bg-[#00FFA3] text-black font-extrabold shadow' : 'text-gray-400 hover:text-white'
                }`}
              >
                {tf}
              </button>
            ))}
          </div>

          {/* Indicator Toggles */}
          <div className="flex items-center space-x-1 bg-[#111111] p-1 rounded-xl border border-[#222222] text-[11px] font-sans">
            <button
              onClick={() => setShowEMA20(!showEMA20)}
              className={`px-2 py-1 rounded-lg transition ${showEMA20 ? 'bg-[#1a1a1a] text-[#00FFA3] border border-[#00FFA3]/40' : 'text-gray-500'}`}
            >
              EMA20
            </button>
            <button
              onClick={() => setShowEMA50(!showEMA50)}
              className={`px-2 py-1 rounded-lg transition ${showEMA50 ? 'bg-[#1a1a1a] text-amber-400 border border-amber-500/40' : 'text-gray-500'}`}
            >
              EMA50
            </button>
            <button
              onClick={() => setShowBB(!showBB)}
              className={`px-2 py-1 rounded-lg transition ${showBB ? 'bg-[#1a1a1a] text-purple-400 border border-purple-500/40' : 'text-gray-500'}`}
            >
              Bollinger
            </button>
            <button
              onClick={() => setShowSupertrend(!showSupertrend)}
              className={`px-2 py-1 rounded-lg transition ${showSupertrend ? 'bg-[#1a1a1a] text-[#00FFA3] border border-[#00FFA3]/40' : 'text-gray-500'}`}
            >
              Supertrend
            </button>
            <button
              onClick={() => setShowTradeLevels(!showTradeLevels)}
              className={`px-2 py-1 rounded-lg transition ${showTradeLevels ? 'bg-[#1a1a1a] text-[#00FFA3] border border-[#00FFA3]/40' : 'text-gray-500'}`}
            >
              Signals
            </button>
          </div>
        </div>
      </div>

      {/* OHLC Bar Hover Header */}
      <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 py-2 px-1 border-b border-slate-800/60">
        {hoveredCandle ? (
          <div className="flex items-center space-x-4">
            <span>T: <strong className="text-white">{hoveredCandle.timeLabel}</strong></span>
            <span>O: <strong className="text-white">${hoveredCandle.open.toFixed(2)}</strong></span>
            <span>H: <strong className="text-emerald-400">${hoveredCandle.high.toFixed(2)}</strong></span>
            <span>L: <strong className="text-rose-400">${hoveredCandle.low.toFixed(2)}</strong></span>
            <span>C: <strong className="text-white">${hoveredCandle.close.toFixed(2)}</strong></span>
            <span>RSI: <strong className="text-amber-400">{hoveredCandle.rsi || 65}</strong></span>
          </div>
        ) : (
          <div className="flex items-center space-x-3 text-slate-400">
            <span>Hover candle for OHLC details & Indicator values</span>
            <span className="text-emerald-400 font-bold">• Live 99% Accuracy Reversal Engine Active</span>
          </div>
        )}
      </div>

      {/* SVG Candlestick Canvas Container */}
      <div className="relative w-full mt-2" style={{ height: `${svgHeight}px` }}>
        <svg
          ref={svgRef}
          width="100%"
          height={svgHeight}
          className="overflow-visible select-none"
          onMouseLeave={() => setHoveredCandle(null)}
        >
          {/* Background Grid Lines */}
          {[0.2, 0.4, 0.6, 0.8].map((pct, idx) => {
            const gridY = chartPaddingTop + chartHeight * pct;
            const gridPrice = maxPrice - (maxPrice - minPrice) * pct;
            return (
              <g key={idx}>
                <line
                  x1={0}
                  y1={gridY}
                  x2={svgWidth}
                  y2={gridY}
                  stroke="#334155"
                  strokeWidth="0.5"
                  strokeDasharray="4 4"
                />
                <text x={svgWidth - 5} y={gridY - 4} fill="#64748b" fontSize="10" textAnchor="end" fontFamily="monospace">
                  ${gridPrice < 1 ? gridPrice.toFixed(4) : gridPrice.toFixed(2)}
                </text>
              </g>
            );
          })}

          {/* Support & Resistance Pivot Lines */}
          <line
            x1={0}
            y1={getY(resistancePivot)}
            x2={svgWidth}
            y2={getY(resistancePivot)}
            stroke="#f43f5e"
            strokeWidth="1"
            strokeDasharray="3 3"
          />
          <text x={10} y={getY(resistancePivot) - 4} fill="#f43f5e" fontSize="10" fontWeight="bold">
            Key Resistance: ${resistancePivot.toFixed(2)}
          </text>

          <line
            x1={0}
            y1={getY(supportPivot)}
            x2={svgWidth}
            y2={getY(supportPivot)}
            stroke="#10b981"
            strokeWidth="1"
            strokeDasharray="3 3"
          />
          <text x={10} y={getY(supportPivot) + 12} fill="#10b981" fontSize="10" fontWeight="bold">
            Key Support: ${supportPivot.toFixed(2)}
          </text>

          {/* Active Signal Lines Overlay (Entry, Stop Loss, Target 1, 2, 3) */}
          {activeSignal && showTradeLevels && (
            <g>
              {/* Stop Loss (Red) */}
              <line
                x1={0}
                y1={getY(activeSignal.stopLoss)}
                x2={svgWidth}
                y2={getY(activeSignal.stopLoss)}
                stroke="#ef4444"
                strokeWidth="1.5"
              />
              <rect
                x={svgWidth - 110}
                y={getY(activeSignal.stopLoss) - 10}
                width={100}
                height={18}
                rx={4}
                fill="#ef4444"
              />
              <text x={svgWidth - 60} y={getY(activeSignal.stopLoss) + 3} fill="#ffffff" fontSize="10" fontWeight="bold" textAnchor="middle">
                STOP LOSS: ${activeSignal.stopLoss}
              </text>

              {/* Entry Price (Cyan) */}
              <line
                x1={0}
                y1={getY(activeSignal.currentPrice)}
                x2={svgWidth}
                y2={getY(activeSignal.currentPrice)}
                stroke="#06b6d4"
                strokeWidth="1.5"
                strokeDasharray="6 3"
              />
              <rect
                x={svgWidth - 110}
                y={getY(activeSignal.currentPrice) - 10}
                width={100}
                height={18}
                rx={4}
                fill="#06b6d4"
              />
              <text x={svgWidth - 60} y={getY(activeSignal.currentPrice) + 3} fill="#ffffff" fontSize="10" fontWeight="bold" textAnchor="middle">
                ENTRY: ${activeSignal.currentPrice}
              </text>

              {/* Target 1 (Green) */}
              <line
                x1={0}
                y1={getY(activeSignal.tp1)}
                x2={svgWidth}
                y2={getY(activeSignal.tp1)}
                stroke="#10b981"
                strokeWidth="1.5"
              />
              <rect
                x={svgWidth - 110}
                y={getY(activeSignal.tp1) - 10}
                width={100}
                height={18}
                rx={4}
                fill="#10b981"
              />
              <text x={svgWidth - 60} y={getY(activeSignal.tp1) + 3} fill="#ffffff" fontSize="10" fontWeight="bold" textAnchor="middle">
                TARGET 1: ${activeSignal.tp1}
              </text>
            </g>
          )}

          {/* EMA 20 Line (Blue) */}
          {showEMA20 && (
            <polyline
              fill="none"
              stroke="#3b82f6"
              strokeWidth="1.5"
              points={candles
                .map((c, i) => `${i * candleGap + candleGap / 2},${getY(c.ema20 || c.close)}`)
                .join(' ')}
            />
          )}

          {/* EMA 50 Line (Amber) */}
          {showEMA50 && (
            <polyline
              fill="none"
              stroke="#f59e0b"
              strokeWidth="1.5"
              points={candles
                .map((c, i) => `${i * candleGap + candleGap / 2},${getY(c.ema50 || c.close)}`)
                .join(' ')}
            />
          )}

          {/* Bollinger Bands Shading */}
          {showBB && (
            <g>
              <polygon
                fill="rgba(168, 85, 247, 0.08)"
                points={[
                  ...candles.map((c, i) => `${i * candleGap + candleGap / 2},${getY(c.upperBB || c.high)}`),
                  ...candles
                    .slice()
                    .reverse()
                    .map((c, i) => `${(candles.length - 1 - i) * candleGap + candleGap / 2},${getY(c.lowerBB || c.low)}`),
                ].join(' ')}
              />
            </g>
          )}

          {/* Render Candlesticks */}
          {candles.map((c, idx) => {
            const x = idx * candleGap + candleGap / 2;
            const isGreen = c.close >= c.open;
            const candleColor = isGreen ? '#10b981' : '#f43f5e';

            const yOpen = getY(c.open);
            const yClose = getY(c.close);
            const yHigh = getY(c.high);
            const yLow = getY(c.low);

            const bodyY = Math.min(yOpen, yClose);
            const bodyH = Math.max(2, Math.abs(yOpen - yClose));

            const volY = getVolY(c.volume);
            const volH = svgHeight - volY;

            return (
              <g
                key={idx}
                className="cursor-pointer"
                onMouseEnter={() => setHoveredCandle(c)}
              >
                {/* Volume Bar */}
                <rect
                  x={x - candleWidth / 2}
                  y={volY}
                  width={candleWidth}
                  height={volH}
                  fill={isGreen ? 'rgba(16, 185, 129, 0.25)' : 'rgba(244, 63, 94, 0.25)'}
                />

                {/* Upper and Lower Wick */}
                <line
                  x1={x}
                  y1={yHigh}
                  x2={x}
                  y2={yLow}
                  stroke={candleColor}
                  strokeWidth="1"
                />

                {/* Candle Body */}
                <rect
                  x={x - candleWidth / 2}
                  y={bodyY}
                  width={candleWidth}
                  height={bodyH}
                  fill={candleColor}
                  rx="1"
                />

                {/* Supertrend Indicator Dot */}
                {showSupertrend && c.supertrend && (
                  <circle
                    cx={x}
                    cy={getY(c.supertrend)}
                    r="2"
                    fill={c.isSupertrendBullish ? '#10b981' : '#f43f5e'}
                  />
                )}
              </g>
            );
          })}

          {/* Candlestick Pattern Overlay Badge on Last Candle */}
          {patterns.length > 0 && (
            <g>
              {patterns.map((p, pIdx) => {
                const targetIdx = p.candleIndex;
                const x = targetIdx * candleGap + candleGap / 2;
                const candle = candles[targetIdx];
                const yVal = p.type === 'bullish' ? getY(candle.low) + 24 : getY(candle.high) - 24;

                return (
                  <g key={pIdx}>
                    <line
                      x1={x}
                      y1={p.type === 'bullish' ? getY(candle.low) + 5 : getY(candle.high) - 5}
                      x2={x}
                      y2={yVal}
                      stroke={p.type === 'bullish' ? '#10b981' : '#f43f5e'}
                      strokeWidth="1.5"
                    />
                    <circle
                      cx={x}
                      cy={yVal}
                      r="12"
                      fill={p.type === 'bullish' ? '#10b981' : '#f43f5e'}
                    />
                    <text
                      x={x}
                      y={yVal + 4}
                      fill="#ffffff"
                      fontSize="10"
                      fontWeight="bold"
                      textAnchor="middle"
                    >
                      {p.type === 'bullish' ? '▲' : '▼'}
                    </text>
                  </g>
                );
              })}
            </g>
          )}
        </svg>
      </div>

      {/* Pattern & Analysis Footer Badge */}
      <div className="mt-4 pt-3 border-t border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
        {patterns.length > 0 ? (
          <div className="flex items-center space-x-3 bg-slate-950 px-4 py-2 rounded-xl border border-slate-800">
            <Zap className="w-5 h-5 text-amber-400 shrink-0 animate-pulse" />
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-xs font-bold text-white">
                  Active Pattern: <span className="text-amber-400">{patterns[0].patternName}</span>
                </span>
                <span className="bg-emerald-500/20 text-emerald-400 text-[10px] font-mono px-2 py-0.5 rounded-md font-bold">
                  {patterns[0].confidence}% Accuracy
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">{patterns[0].description}</p>
            </div>
          </div>
        ) : null}

        <div className="flex items-center space-x-3 text-xs text-slate-400 font-mono">
          <span className="flex items-center space-x-1">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-500 inline-block"></span>
            <span>EMA 20</span>
          </span>
          <span className="flex items-center space-x-1">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500 inline-block"></span>
            <span>EMA 50</span>
          </span>
          <span className="flex items-center space-x-1">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block"></span>
            <span>Supertrend</span>
          </span>
        </div>
      </div>
    </div>
  );
};
