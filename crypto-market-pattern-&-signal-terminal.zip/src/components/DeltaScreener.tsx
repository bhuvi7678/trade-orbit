import React, { useState } from 'react';
import { CryptoCoin } from '../types';
import { Zap, Search, TrendingUp, TrendingDown, Flame, ShieldAlert, ArrowRight, Activity, Filter } from 'lucide-react';

interface DeltaScreenerProps {
  coins: CryptoCoin[];
  onSelectCoin: (coin: CryptoCoin) => void;
  onOpenSignalTab: () => void;
}

export const DeltaScreener: React.FC<DeltaScreenerProps> = ({
  coins,
  onSelectCoin,
  onOpenSignalTab,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');

  // Filter logic
  const filteredCoins = coins.filter((coin) => {
    const matchesSearch = coin.symbol.toLowerCase().includes(searchTerm.toLowerCase()) || coin.name.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (selectedCategory === 'ALL') return matchesSearch;
    if (selectedCategory === 'DELTA_TOP') return matchesSearch && coin.category === 'Delta Exchange Top';
    if (selectedCategory === 'HIGH_MOMENTUM') return matchesSearch && coin.momentumScore >= 80;
    if (selectedCategory === 'BULL_BOTTOM') return matchesSearch && coin.isReversalBottom;
    if (selectedCategory === 'BEAR_TOP') return matchesSearch && coin.isReversalTop;
    return matchesSearch;
  });

  return (
    <div className="space-y-6">
      {/* Top Screener Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <Zap className="w-6 h-6 text-amber-400 animate-pulse" />
              <h2 className="text-xl font-bold text-white font-sans">
                Delta Exchange Coin Momentum & Pattern Screener
              </h2>
            </div>
            <p className="text-xs text-slate-400 mt-1 max-w-2xl">
              Real-time candlestick pattern scanner across Delta Exchange coins. Detects explosive momentum breakouts, support retests, and top rejection warnings before the move occurs.
            </p>
          </div>

          {/* Quick Metrics */}
          <div className="flex items-center space-x-4 bg-slate-950 p-3 rounded-xl border border-slate-800 font-mono text-xs">
            <div>
              <span className="text-slate-400 block text-[10px] uppercase">Delta Top Movers</span>
              <span className="text-emerald-400 font-bold">{coins.filter(c => c.change24h > 5).length} Coins Pumped</span>
            </div>
            <div className="w-px h-8 bg-slate-800"></div>
            <div>
              <span className="text-slate-400 block text-[10px] uppercase">Bottom Setups</span>
              <span className="text-cyan-400 font-bold">{coins.filter(c => c.isReversalBottom).length} High Accuracy</span>
            </div>
          </div>
        </div>

        {/* Filter Controls Bar */}
        <div className="mt-6 flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-slate-800">
          {/* Category Tabs */}
          <div className="flex items-center space-x-2 overflow-x-auto no-scrollbar w-full sm:w-auto text-xs font-medium">
            <button
              onClick={() => setSelectedCategory('ALL')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                selectedCategory === 'ALL' ? 'bg-emerald-500 text-slate-950 font-bold shadow' : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              All Pairs ({coins.length})
            </button>
            <button
              onClick={() => setSelectedCategory('DELTA_TOP')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                selectedCategory === 'DELTA_TOP' ? 'bg-emerald-500 text-slate-950 font-bold shadow' : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              Delta Exchange Pairs
            </button>
            <button
              onClick={() => setSelectedCategory('HIGH_MOMENTUM')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                selectedCategory === 'HIGH_MOMENTUM' ? 'bg-emerald-500 text-slate-950 font-bold shadow' : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              High Momentum 🔥
            </button>
            <button
              onClick={() => setSelectedCategory('BULL_BOTTOM')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                selectedCategory === 'BULL_BOTTOM' ? 'bg-emerald-500 text-slate-950 font-bold shadow' : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              Bull Run Bottoms
            </button>
            <button
              onClick={() => setSelectedCategory('BEAR_TOP')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                selectedCategory === 'BEAR_TOP' ? 'bg-emerald-500 text-slate-950 font-bold shadow' : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              Top Fall Warnings
            </button>
          </div>

          {/* Search Box */}
          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
            <input
              type="text"
              placeholder="Search coin symbol (BTC, DETO...)"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 text-xs text-white pl-9 pr-3 py-2 rounded-xl focus:outline-none focus:border-emerald-500"
            />
          </div>
        </div>
      </div>

      {/* Coins Screener Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-950 border-b border-slate-800 text-[11px] font-mono text-slate-400 uppercase tracking-wider">
                <th className="p-4">Crypto Pair</th>
                <th className="p-4">Live Price</th>
                <th className="p-4">24h Change</th>
                <th className="p-4">Active Pattern</th>
                <th className="p-4">Momentum Score</th>
                <th className="p-4">RSI (14)</th>
                <th className="p-4">Signal Status</th>
                <th className="p-4 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-xs font-sans">
              {filteredCoins.map((coin) => {
                const isBullish = coin.trendSignal.includes('BULL');
                return (
                  <tr
                    key={coin.symbol}
                    className="hover:bg-slate-800/50 transition-all cursor-pointer"
                    onClick={() => onSelectCoin(coin)}
                  >
                    {/* Pair Name */}
                    <td className="p-4 font-bold text-white">
                      <div className="flex items-center space-x-2">
                        <span className="text-sm">{coin.symbol}</span>
                        <span className="text-[10px] text-slate-400 bg-slate-800 px-1.5 py-0.5 rounded font-mono">
                          {coin.category}
                        </span>
                      </div>
                      <span className="text-[11px] text-slate-400 font-normal">{coin.name}</span>
                    </td>

                    {/* Price */}
                    <td className="p-4 font-mono font-bold text-slate-100">
                      ${coin.price < 1 ? coin.price.toFixed(4) : coin.price.toLocaleString()}
                    </td>

                    {/* 24h Change */}
                    <td className="p-4 font-mono font-bold">
                      <span
                        className={`inline-flex items-center space-x-1 px-2 py-0.5 rounded ${
                          coin.change24h >= 0 ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'
                        }`}
                      >
                        {coin.change24h >= 0 ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                        <span>{coin.change24h >= 0 ? '+' : ''}{coin.change24h}%</span>
                      </span>
                    </td>

                    {/* Active Candlestick Pattern */}
                    <td className="p-4 font-medium text-amber-300">
                      <div className="flex items-center space-x-1.5">
                        <Activity className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                        <span>{coin.activePattern}</span>
                      </div>
                    </td>

                    {/* Momentum Gauge */}
                    <td className="p-4">
                      <div className="flex items-center space-x-2">
                        <div className="w-16 h-2 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                          <div
                            className={`h-full ${
                              coin.momentumScore >= 80
                                ? 'bg-emerald-400'
                                : coin.momentumScore >= 50
                                ? 'bg-amber-400'
                                : 'bg-rose-500'
                            }`}
                            style={{ width: `${coin.momentumScore}%` }}
                          ></div>
                        </div>
                        <span className="font-mono font-bold text-slate-300">{coin.momentumScore}/100</span>
                      </div>
                    </td>

                    {/* RSI */}
                    <td className="p-4 font-mono font-bold text-slate-300">
                      <span
                        className={
                          coin.rsi >= 70 ? 'text-amber-400 font-extrabold' : coin.rsi <= 30 ? 'text-cyan-400 font-extrabold' : 'text-slate-300'
                        }
                      >
                        {coin.rsi}
                      </span>
                    </td>

                    {/* Signal Status */}
                    <td className="p-4">
                      {coin.isReversalBottom ? (
                        <span className="bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 font-bold px-2.5 py-1 rounded-md text-[11px] inline-flex items-center space-x-1">
                          <Flame className="w-3 h-3 text-emerald-400" />
                          <span>Bull Bottom (99% Acc)</span>
                        </span>
                      ) : coin.isReversalTop ? (
                        <span className="bg-rose-500/20 border border-rose-500/40 text-rose-400 font-bold px-2.5 py-1 rounded-md text-[11px] inline-flex items-center space-x-1">
                          <ShieldAlert className="w-3 h-3 text-rose-400" />
                          <span>Top Fall Warning</span>
                        </span>
                      ) : (
                        <span
                          className={`font-bold px-2.5 py-1 rounded-md text-[11px] ${
                            isBullish ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400'
                          }`}
                        >
                          {coin.trendSignal}
                        </span>
                      )}
                    </td>

                    {/* Action */}
                    <td className="p-4 text-right">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectCoin(coin);
                          onOpenSignalTab();
                        }}
                        className="bg-slate-800 hover:bg-emerald-500 hover:text-slate-950 text-emerald-400 border border-emerald-500/30 px-3 py-1.5 rounded-lg transition-all font-semibold inline-flex items-center space-x-1 text-xs"
                      >
                        <span>Open Setup</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
