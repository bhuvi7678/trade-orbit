import React, { useState } from 'react';
import { MarketAlert, CryptoCoin } from '../types';
import { Bell, ShieldAlert, CheckCircle2, Volume2, Plus, Trash2, Flame, Zap, Clock } from 'lucide-react';

interface AlertsManagerProps {
  alerts: MarketAlert[];
  coins: CryptoCoin[];
  onTriggerAudioAlert: () => void;
  onClearAlerts: () => void;
  onAddCustomAlert: (alert: MarketAlert) => void;
}

export const AlertsManager: React.FC<AlertsManagerProps> = ({
  alerts,
  coins,
  onTriggerAudioAlert,
  onClearAlerts,
  onAddCustomAlert,
}) => {
  const [selectedCoinSymbol, setSelectedCoinSymbol] = useState(coins[0]?.symbol || 'BTC/USDT');
  const [triggerPrice, setTriggerPrice] = useState<string>('');
  const [alertTitle, setAlertTitle] = useState('');
  const [alertType, setAlertType] = useState<'ENTRY' | 'EXIT_TP' | 'REJECTION_WARNING'>('ENTRY');

  const handleCreateAlert = (e: React.FormEvent) => {
    e.preventDefault();
    if (!triggerPrice) return;

    const coin = coins.find((c) => c.symbol === selectedCoinSymbol) || coins[0];
    const newAlert: MarketAlert = {
      id: `custom-alt-${Date.now()}`,
      symbol: coin.symbol,
      title: alertTitle || `Custom Price Alert for ${coin.symbol}`,
      message: `Price alert set at $${triggerPrice}. System will play audio notification on touch.`,
      price: parseFloat(triggerPrice),
      type: alertType,
      timestamp: 'Just now',
      isRead: false,
      accuracy: 99.0,
      timeframe: '15m',
    };

    onAddCustomAlert(newAlert);
    onTriggerAudioAlert();
    setTriggerPrice('');
    setAlertTitle('');
    alert(`✅ Custom Alert Created for ${coin.symbol} at $${triggerPrice}`);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <Bell className="w-6 h-6 text-amber-400 animate-pulse" />
              <h2 className="text-xl font-bold text-white font-sans">
                Automatic Entry & Exit Notification Center
              </h2>
            </div>
            <p className="text-xs text-slate-400 mt-1 max-w-2xl">
              Automatic alert triggers when a coin enters high-accuracy buy range, hits Take-Profit target, or detects top/bottom rejection patterns.
            </p>
          </div>

          <div className="flex items-center space-x-3">
            <button
              onClick={onTriggerAudioAlert}
              className="bg-slate-800 hover:bg-slate-700 text-amber-400 border border-amber-500/30 font-bold px-3 py-2 rounded-xl text-xs transition inline-flex items-center space-x-1.5"
            >
              <Volume2 className="w-4 h-4" />
              <span>Test Audio Sound</span>
            </button>

            {alerts.length > 0 && (
              <button
                onClick={onClearAlerts}
                className="bg-rose-500/10 hover:bg-rose-500 hover:text-white text-rose-400 border border-rose-500/30 font-bold px-3 py-2 rounded-xl text-xs transition inline-flex items-center space-x-1.5"
              >
                <Trash2 className="w-4 h-4" />
                <span>Clear Logs</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Create Custom Alert Form */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-2xl">
        <h3 className="text-sm font-bold text-white uppercase tracking-wider mb-4 flex items-center space-x-2 font-sans">
          <Plus className="w-4 h-4 text-emerald-400" />
          <span>Create Custom Price or Pattern Alert</span>
        </h3>

        <form onSubmit={handleCreateAlert} className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs font-sans">
          <div>
            <label className="text-slate-400 block mb-1">Select Pair</label>
            <select
              value={selectedCoinSymbol}
              onChange={(e) => setSelectedCoinSymbol(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 text-white font-bold p-2.5 rounded-xl focus:outline-none focus:border-emerald-500"
            >
              {coins.map((c) => (
                <option key={c.symbol} value={c.symbol}>
                  {c.symbol} (${c.price})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Target Trigger Price ($)</label>
            <input
              type="number"
              step="any"
              placeholder="e.g. 94500"
              value={triggerPrice}
              onChange={(e) => setTriggerPrice(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 text-white font-bold p-2.5 rounded-xl focus:outline-none focus:border-emerald-500 font-mono"
            />
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Alert Category</label>
            <select
              value={alertType}
              onChange={(e: any) => setAlertType(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 text-white font-bold p-2.5 rounded-xl focus:outline-none focus:border-emerald-500"
            >
              <option value="ENTRY">Entry Signal Alert</option>
              <option value="EXIT_TP">Take Profit Alert</option>
              <option value="REJECTION_WARNING">Top Rejection Warning</option>
            </select>
          </div>

          <div className="flex items-end">
            <button
              type="submit"
              className="w-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold p-2.5 rounded-xl transition shadow text-xs flex items-center justify-center space-x-1"
            >
              <Plus className="w-4 h-4" />
              <span>Add Live Alert</span>
            </button>
          </div>
        </form>
      </div>

      {/* Alert Feed Logs */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-2xl space-y-4">
        <h3 className="text-sm font-bold text-white uppercase tracking-wider pb-3 border-b border-slate-800 flex items-center justify-between font-sans">
          <span>Live Notification Logs ({alerts.length})</span>
          <span className="text-xs text-slate-400 font-mono font-normal">Auto Updates Active</span>
        </h3>

        <div className="space-y-3">
          {alerts.map((alt) => {
            const isRejection = alt.type === 'REJECTION_WARNING';
            const isBottom = alt.type === 'BOTTOM_HUNTER';

            return (
              <div
                key={alt.id}
                className={`p-4 rounded-xl border ${
                  isRejection
                    ? 'bg-rose-950/20 border-rose-500/30'
                    : isBottom
                    ? 'bg-emerald-950/20 border-emerald-500/30'
                    : 'bg-slate-950 border-slate-800'
                } flex items-start justify-between gap-4 transition-all hover:border-slate-700`}
              >
                <div className="flex items-start space-x-3">
                  <div
                    className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${
                      isRejection
                        ? 'bg-rose-500/20 text-rose-400'
                        : isBottom
                        ? 'bg-emerald-500/20 text-emerald-400'
                        : 'bg-amber-500/20 text-amber-400'
                    }`}
                  >
                    {isRejection ? <ShieldAlert className="w-5 h-5" /> : isBottom ? <Flame className="w-5 h-5" /> : <Zap className="w-5 h-5" />}
                  </div>

                  <div>
                    <div className="flex items-center space-x-2">
                      <h4 className="text-sm font-bold text-white font-sans">{alt.title}</h4>
                      <span className="text-[10px] bg-slate-800 text-slate-300 font-mono px-2 py-0.5 rounded">
                        {alt.symbol}
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 mt-1 leading-relaxed">{alt.message}</p>
                    <div className="flex items-center space-x-4 mt-2 text-[11px] font-mono text-slate-400">
                      <span className="flex items-center space-x-1">
                        <Clock className="w-3 h-3 text-slate-500" />
                        <span>{alt.timestamp}</span>
                      </span>
                      <span>Target Price: <strong className="text-white">${alt.price}</strong></span>
                      <span className="text-emerald-400 font-bold">{alt.accuracy}% Accuracy</span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
