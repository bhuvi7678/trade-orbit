import React from 'react';
import { CryptoCoin, TradeSignal } from '../types';
import { Flame, ShieldAlert, CheckCircle2, TrendingUp, TrendingDown, Target, Zap, ArrowUpRight, ArrowDownRight, BellRing } from 'lucide-react';

interface TopBottomHunterProps {
  signals: TradeSignal[];
  coins: CryptoCoin[];
  onSelectCoin: (coin: CryptoCoin) => void;
  onTriggerAudioAlert: () => void;
}

export const TopBottomHunter: React.FC<TopBottomHunterProps> = ({
  signals,
  coins,
  onSelectCoin,
  onTriggerAudioAlert,
}) => {
  const bottomSignals = signals.filter((s) => s.isBullRunBottom || s.direction === 'LONG');
  const topCrashSignals = signals.filter((s) => s.isTopCrashReversal || s.direction === 'SHORT');

  return (
    <div className="space-y-8">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-slate-950 border border-slate-800 rounded-2xl p-6 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <Flame className="w-6 h-6 text-emerald-400 animate-bounce" />
              <h2 className="text-xl font-extrabold text-white font-sans">
                Market Top & Bottom Reversal Hunter (99% Accuracy)
              </h2>
            </div>
            <p className="text-xs text-slate-300 mt-1 max-w-2xl leading-relaxed">
              Market mein jab bhi Bull Run start hone wala ho to exact bottom par entry identify karta hai aur top par market fall hone se pehle hi rejection detect karke warn kar deta hai with extremely tight Stop Loss (Small SL).
            </p>
          </div>

          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex items-center space-x-3 shrink-0 font-mono text-xs">
            <div className="text-center">
              <span className="text-slate-400 block text-[10px] uppercase">Bottom Accuracy</span>
              <span className="text-emerald-400 text-base font-extrabold">99.1%</span>
            </div>
            <div className="w-px h-8 bg-slate-800"></div>
            <div className="text-center">
              <span className="text-slate-400 block text-[10px] uppercase">Avg Small SL</span>
              <span className="text-amber-400 text-base font-extrabold">~0.4%</span>
            </div>
          </div>
        </div>
      </div>

      {/* SECTION 1: Bull Run Bottom Hunter (Buy the Dip) */}
      <div className="space-y-4">
        <div className="flex items-center space-x-3 border-b border-slate-800 pb-3">
          <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center">
            <ArrowUpRight className="w-5 h-5 text-emerald-400" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white font-sans">
              🟢 Bull Run Bottom Identified (Strong Reversal Buy Zone)
            </h3>
            <p className="text-xs text-slate-400">
              Double Bottom W-Pattern & Support Rejection setups with small SL
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {bottomSignals.map((signal) => {
            const coin = coins.find((c) => c.symbol === signal.symbol) || coins[0];
            return (
              <div
                key={signal.id}
                onClick={() => onSelectCoin(coin)}
                className="bg-slate-900 border border-emerald-500/30 hover:border-emerald-500 rounded-2xl p-5 shadow-xl hover:shadow-emerald-500/10 transition-all cursor-pointer relative overflow-hidden group"
              >
                {/* Header */}
                <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                  <div className="flex items-center space-x-2">
                    <span className="text-base font-extrabold text-white">{signal.symbol}</span>
                    <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-[10px] font-mono px-2 py-0.5 rounded font-bold">
                      {signal.timeframe} BOTTOM SETUP
                    </span>
                  </div>
                  <span className="bg-emerald-500 text-slate-950 font-black text-xs px-3 py-1 rounded-full shadow">
                    {signal.accuracyScore}% ACCURACY
                  </span>
                </div>

                {/* Pattern & Confluence */}
                <div className="mt-3 bg-slate-950 p-3 rounded-xl border border-slate-800/80">
                  <div className="flex items-center justify-between text-xs font-mono">
                    <span className="text-slate-400">Candlestick Pattern:</span>
                    <span className="text-amber-400 font-bold">{signal.patternTrigger}</span>
                  </div>
                  <div className="flex items-center justify-between text-xs font-mono mt-1">
                    <span className="text-slate-400">Current Price:</span>
                    <span className="text-white font-bold">${signal.currentPrice}</span>
                  </div>
                </div>

                {/* Exact Entry, Small SL, TP Breakdown */}
                <div className="mt-4 grid grid-cols-3 gap-2 text-center font-mono text-xs">
                  <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                    <span className="text-[10px] text-slate-400 block uppercase font-sans">Buy Entry Range</span>
                    <strong className="text-cyan-400 text-xs block mt-0.5">
                      ${signal.entryRangeMin} - ${signal.entryRangeMax}
                    </strong>
                  </div>

                  <div className="bg-slate-950 p-2.5 rounded-xl border border-rose-500/30">
                    <span className="text-[10px] text-rose-400 block uppercase font-sans font-bold">Tight Small SL</span>
                    <strong className="text-rose-400 text-xs block mt-0.5">
                      ${signal.stopLoss} ({signal.smallSLPercent}%)
                    </strong>
                  </div>

                  <div className="bg-slate-950 p-2.5 rounded-xl border border-emerald-500/30">
                    <span className="text-[10px] text-emerald-400 block uppercase font-sans font-bold">Target 1 (TP)</span>
                    <strong className="text-emerald-400 text-xs block mt-0.5">${signal.tp1}</strong>
                  </div>
                </div>

                {/* Rationale Bullet Points */}
                <div className="mt-4 space-y-1 text-[11px] text-slate-300">
                  {signal.confluenceReason.slice(0, 2).map((reason, idx) => (
                    <div key={idx} className="flex items-center space-x-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span>{reason}</span>
                    </div>
                  ))}
                </div>

                {/* Action Bar */}
                <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between">
                  <span className="text-[11px] text-slate-400 font-mono">
                    R:R Ratio <strong className="text-emerald-400 font-bold">{signal.riskRewardRatio}</strong>
                  </span>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onTriggerAudioAlert();
                      alert(`🔔 Alert Set for ${signal.symbol} Bull Bottom Entry! System will notify when price enters $${signal.entryRangeMin}`);
                    }}
                    className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold px-3 py-1.5 rounded-lg text-xs transition inline-flex items-center space-x-1.5 shadow"
                  >
                    <BellRing className="w-3.5 h-3.5" />
                    <span>Set Auto Entry Alert</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* SECTION 2: Market Top Fall & Rejection Hunter */}
      <div className="space-y-4 pt-4 border-t border-slate-800">
        <div className="flex items-center space-x-3 border-b border-slate-800 pb-3">
          <div className="w-8 h-8 rounded-lg bg-rose-500/20 border border-rose-500/40 flex items-center justify-center">
            <ArrowDownRight className="w-5 h-5 text-rose-400" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white font-sans">
              🔴 Market Top Fall Rejection (Short Setup / Take Profit)
            </h3>
            <p className="text-xs text-slate-400">
              Identifies top resistance rejection BEFORE price crashes, preventing long trap
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {topCrashSignals.map((signal) => {
            const coin = coins.find((c) => c.symbol === signal.symbol) || coins[0];
            return (
              <div
                key={signal.id}
                onClick={() => onSelectCoin(coin)}
                className="bg-slate-900 border border-rose-500/30 hover:border-rose-500 rounded-2xl p-5 shadow-xl hover:shadow-rose-500/10 transition-all cursor-pointer relative overflow-hidden group"
              >
                {/* Header */}
                <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                  <div className="flex items-center space-x-2">
                    <span className="text-base font-extrabold text-white">{signal.symbol}</span>
                    <span className="bg-rose-500/20 text-rose-400 border border-rose-500/40 text-[10px] font-mono px-2 py-0.5 rounded font-bold">
                      TOP REJECTION FALL
                    </span>
                  </div>
                  <span className="bg-rose-500 text-white font-black text-xs px-3 py-1 rounded-full shadow">
                    {signal.accuracyScore}% REJECTION ACCURACY
                  </span>
                </div>

                {/* Pattern & Warning */}
                <div className="mt-3 bg-slate-950 p-3 rounded-xl border border-slate-800/80">
                  <div className="flex items-center space-x-2 text-rose-400 font-bold text-xs font-sans">
                    <ShieldAlert className="w-4 h-4" />
                    <span>Move Se Pehle Rejection Detected!</span>
                  </div>
                  <p className="text-xs text-slate-300 mt-1">
                    Top resistance touched at ${signal.currentPrice}. Long trades are rejected by system. Short entry active with small SL.
                  </p>
                </div>

                {/* Entry, SL, TP */}
                <div className="mt-4 grid grid-cols-3 gap-2 text-center font-mono text-xs">
                  <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                    <span className="text-[10px] text-slate-400 block uppercase font-sans">Short Entry Range</span>
                    <strong className="text-rose-400 text-xs block mt-0.5">${signal.entryRangeMax}</strong>
                  </div>

                  <div className="bg-slate-950 p-2.5 rounded-xl border border-amber-500/30">
                    <span className="text-[10px] text-amber-400 block uppercase font-sans font-bold">Small SL (Tight)</span>
                    <strong className="text-amber-400 text-xs block mt-0.5">
                      ${signal.stopLoss} ({signal.smallSLPercent}%)
                    </strong>
                  </div>

                  <div className="bg-slate-950 p-2.5 rounded-xl border border-emerald-500/30">
                    <span className="text-[10px] text-emerald-400 block uppercase font-sans font-bold">Target 1 (Fall TP)</span>
                    <strong className="text-emerald-400 text-xs block mt-0.5">${signal.tp1}</strong>
                  </div>
                </div>

                {/* Action Bar */}
                <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between">
                  <span className="text-[11px] text-slate-400 font-mono">
                    R:R Ratio <strong className="text-rose-400 font-bold">{signal.riskRewardRatio}</strong>
                  </span>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onTriggerAudioAlert();
                      alert(`⚠️ Top Fall Rejection Alert Enabled for ${signal.symbol}! System will warn before market breaks down.`);
                    }}
                    className="bg-rose-500 hover:bg-rose-400 text-white font-bold px-3 py-1.5 rounded-lg text-xs transition inline-flex items-center space-x-1.5 shadow"
                  >
                    <BellRing className="w-3.5 h-3.5" />
                    <span>Set Rejection Alert</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
