import React, { useState } from 'react';
import { TradeSignal, TimeFrame, CryptoCoin } from '../types';
import { Target, TrendingUp, TrendingDown, Copy, Check, ShieldCheck, Zap, Bell, Clock, Filter } from 'lucide-react';

interface TradeSignalsListProps {
  signals: TradeSignal[];
  coins: CryptoCoin[];
  onSelectCoin: (coin: CryptoCoin) => void;
  onTriggerAudioAlert: () => void;
}

export const TradeSignalsList: React.FC<TradeSignalsListProps> = ({
  signals,
  coins,
  onSelectCoin,
  onTriggerAudioAlert,
}) => {
  const [filterDirection, setFilterDirection] = useState<'ALL' | 'LONG' | 'SHORT'>('ALL');
  const [filterTimeframe, setFilterTimeframe] = useState<string>('ALL');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const filteredSignals = signals.filter((signal) => {
    if (filterDirection !== 'ALL' && signal.direction !== filterDirection) return false;
    if (filterTimeframe !== 'ALL' && signal.timeframe !== filterTimeframe) return false;
    return true;
  });

  const handleCopySignal = (signal: TradeSignal) => {
    const text = `🚀 High Accuracy Crypto Signal: ${signal.symbol} (${signal.direction})
Timeframe: ${signal.timeframe}
Entry Zone: $${signal.entryRangeMin} - $${signal.entryRangeMax}
Small SL: $${signal.stopLoss} (${signal.smallSLPercent}%)
Target 1: $${signal.tp1}
Target 2: $${signal.tp2}
Target 3: $${signal.tp3}
Risk Reward: ${signal.riskRewardRatio}
Pattern: ${signal.patternTrigger} (Accuracy: ${signal.accuracyScore}%)`;

    navigator.clipboard.writeText(text);
    setCopiedId(signal.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Filters */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <Target className="w-6 h-6 text-cyan-400 animate-pulse" />
              <h2 className="text-xl font-bold text-white font-sans">
                Automated Entry & Exit Signal Terminal
              </h2>
            </div>
            <p className="text-xs text-slate-400 mt-1 max-w-2xl">
              Automatic trade setup generator with exact entry range, ultra-tight Small Stop Loss (0.3% - 0.7%), and multi-stage Take Profit targets with 99% accuracy validation.
            </p>
          </div>

          {/* Direction Filter Buttons */}
          <div className="flex items-center space-x-2 bg-slate-950 p-1.5 rounded-xl border border-slate-800 text-xs font-mono">
            <button
              onClick={() => setFilterDirection('ALL')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                filterDirection === 'ALL' ? 'bg-emerald-500 text-slate-950 font-bold shadow' : 'text-slate-400 hover:text-white'
              }`}
            >
              All Setups ({signals.length})
            </button>
            <button
              onClick={() => setFilterDirection('LONG')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                filterDirection === 'LONG' ? 'bg-emerald-500 text-slate-950 font-bold shadow' : 'text-slate-400 hover:text-white'
              }`}
            >
              Longs 🟢
            </button>
            <button
              onClick={() => setFilterDirection('SHORT')}
              className={`px-3 py-1.5 rounded-lg transition-all ${
                filterDirection === 'SHORT' ? 'bg-rose-500 text-white font-bold shadow' : 'text-slate-400 hover:text-white'
              }`}
            >
              Shorts 🔴
            </button>
          </div>
        </div>

        {/* Timeframe Filter Tabs */}
        <div className="mt-6 flex items-center space-x-2 pt-4 border-t border-slate-800 text-xs font-mono overflow-x-auto no-scrollbar">
          <span className="text-slate-500 uppercase tracking-wider text-[10px]">Filter Timeframe:</span>
          {['ALL', '1m', '5m', '15m', '1h', '4h', '1d'].map((tf) => (
            <button
              key={tf}
              onClick={() => setFilterTimeframe(tf)}
              className={`px-3 py-1 rounded-md transition ${
                filterTimeframe === tf ? 'bg-slate-800 text-cyan-400 border border-cyan-500/40 font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              {tf === 'ALL' ? 'All Timeframes' : tf}
            </button>
          ))}
        </div>
      </div>

      {/* Signals Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredSignals.map((signal) => {
          const isLong = signal.direction === 'LONG';
          const coin = coins.find((c) => c.symbol === signal.symbol) || coins[0];

          return (
            <div
              key={signal.id}
              onClick={() => onSelectCoin(coin)}
              className={`bg-slate-900 border ${
                isLong ? 'border-emerald-500/30 hover:border-emerald-500' : 'border-rose-500/30 hover:border-rose-500'
              } rounded-2xl p-5 shadow-2xl transition-all cursor-pointer relative flex flex-col justify-between group`}
            >
              {/* Card Top */}
              <div>
                <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                  <div className="flex items-center space-x-2">
                    <span className="text-base font-bold text-white font-sans">{signal.symbol}</span>
                    <span
                      className={`text-[11px] font-mono px-2 py-0.5 rounded font-bold flex items-center space-x-1 ${
                        isLong ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'
                      }`}
                    >
                      {isLong ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
                      <span>{signal.direction} ({signal.timeframe})</span>
                    </span>
                  </div>

                  <span className="bg-slate-950 text-emerald-400 border border-emerald-500/40 text-[10px] font-mono font-bold px-2 py-0.5 rounded-full">
                    {signal.accuracyScore}% Acc
                  </span>
                </div>

                {/* Pattern & Current Price */}
                <div className="mt-3 bg-slate-950 p-3 rounded-xl border border-slate-800 text-xs font-mono">
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">Trigger Pattern:</span>
                    <span className="text-amber-400 font-bold">{signal.patternTrigger}</span>
                  </div>
                  <div className="flex justify-between items-center mt-1">
                    <span className="text-slate-400">Live Price:</span>
                    <span className="text-white font-bold">${signal.currentPrice}</span>
                  </div>
                </div>

                {/* Entry, Small SL, Targets Matrix */}
                <div className="mt-4 space-y-2 text-xs font-mono">
                  <div className="bg-slate-950 p-2.5 rounded-xl border border-cyan-500/30 flex items-center justify-between">
                    <span className="text-slate-400">Entry Range:</span>
                    <span className="text-cyan-400 font-bold">${signal.entryRangeMin} - ${signal.entryRangeMax}</span>
                  </div>

                  <div className="bg-slate-950 p-2.5 rounded-xl border border-rose-500/30 flex items-center justify-between">
                    <span className="text-rose-400 font-bold">Small SL (Tight):</span>
                    <span className="text-rose-400 font-extrabold">${signal.stopLoss} ({signal.smallSLPercent}%)</span>
                  </div>

                  <div className="bg-slate-950 p-2.5 rounded-xl border border-emerald-500/30 space-y-1">
                    <div className="flex justify-between text-[11px]">
                      <span className="text-slate-400">Target 1 (TP1):</span>
                      <span className="text-emerald-400 font-bold">${signal.tp1}</span>
                    </div>
                    <div className="flex justify-between text-[11px]">
                      <span className="text-slate-400">Target 2 (TP2):</span>
                      <span className="text-emerald-400 font-bold">${signal.tp2}</span>
                    </div>
                    <div className="flex justify-between text-[11px]">
                      <span className="text-slate-400">Target 3 (TP3):</span>
                      <span className="text-emerald-400 font-bold">${signal.tp3}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Card Footer Actions */}
              <div className="mt-5 pt-3 border-t border-slate-800 flex items-center justify-between">
                <span className="text-[11px] text-slate-400 font-mono">
                  Risk-Reward: <strong className="text-emerald-400 font-bold">{signal.riskRewardRatio}</strong>
                </span>

                <div className="flex items-center space-x-2">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleCopySignal(signal);
                    }}
                    title="Copy Signal Parameters"
                    className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition"
                  >
                    {copiedId === signal.id ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  </button>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onTriggerAudioAlert();
                      alert(`🔔 Auto Alert Set for ${signal.symbol}! System will play sound when Entry or TP price is hit.`);
                    }}
                    className="bg-emerald-500/20 hover:bg-emerald-500 hover:text-slate-950 text-emerald-400 border border-emerald-500/40 px-3 py-1.5 rounded-lg text-xs font-bold transition inline-flex items-center space-x-1"
                  >
                    <Bell className="w-3.5 h-3.5" />
                    <span>Alert</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
